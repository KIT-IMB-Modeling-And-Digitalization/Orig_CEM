#define SYSIZE 100
extern char mic[SYSIZE][SYSIZE][SYSIZE];
extern short int micpart[SYSIZE][SYSIZE][SYSIZE];
extern char micorig[SYSIZE][SYSIZE][SYSIZE];
extern int count[46];
extern double specgrav[46];
extern double cemmass;
extern double time_cur;
extern double krate;
extern double beta;
extern double alpha_cur;
