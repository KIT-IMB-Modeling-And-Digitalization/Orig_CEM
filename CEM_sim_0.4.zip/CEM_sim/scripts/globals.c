#include "common.h"

char mic[SYSIZE][SYSIZE][SYSIZE];
short int micpart[SYSIZE][SYSIZE][SYSIZE];
char micorig[SYSIZE][SYSIZE][SYSIZE];
