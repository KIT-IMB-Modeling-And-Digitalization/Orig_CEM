To compile the c files, run the following command, it will automatically detect your OS:

python setup.py build_exe


And after compilation to install the package run it:

pip install .

Then you would be able to run the simulation script inside simulation folder which is named disrealnew.py

and to uninstall use:

pip uninstall cement_sim